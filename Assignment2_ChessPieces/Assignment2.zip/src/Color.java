/**
 * Color enum is used to denote colors of a chess piece, as black or white.
 */

public enum Color {
  BLACK,
  WHITE
}
